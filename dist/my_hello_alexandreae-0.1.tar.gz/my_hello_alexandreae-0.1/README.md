# pacote_pip
Atividade para criar um pacote Python instalável via pip.

link da disciplina:https://github.com/Insper/dev-aberto
